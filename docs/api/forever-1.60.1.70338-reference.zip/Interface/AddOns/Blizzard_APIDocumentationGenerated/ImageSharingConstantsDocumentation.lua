local ImageSharingConstants =
{
	Tables =
	{
		{
			Name = "ImageSharingResult",
			Type = "Enumeration",
			NumValues = 15,
			MinValue = 0,
			MaxValue = 14,
			Fields =
			{
				{ Name = "Failure", Type = "ImageSharingResult", EnumValue = 0 },
				{ Name = "Success", Type = "ImageSharingResult", EnumValue = 1 },
				{ Name = "NotConfigured", Type = "ImageSharingResult", EnumValue = 2 },
				{ Name = "RetrievedExisting", Type = "ImageSharingResult", EnumValue = 3 },
				{ Name = "PlatformApiError", Type = "ImageSharingResult", EnumValue = 4 },
				{ Name = "MissingFieldApiError", Type = "ImageSharingResult", EnumValue = 5 },
				{ Name = "AccountDataRequestFailure", Type = "ImageSharingResult", EnumValue = 6 },
				{ Name = "GetAccountDataRequestFailure", Type = "ImageSharingResult", EnumValue = 7 },
				{ Name = "SetAccountDataRequestFailure", Type = "ImageSharingResult", EnumValue = 8 },
				{ Name = "RefreshTokenExpired", Type = "ImageSharingResult", EnumValue = 9 },
				{ Name = "FailedToCreateHeader", Type = "ImageSharingResult", EnumValue = 10 },
				{ Name = "EncryptionFailure", Type = "ImageSharingResult", EnumValue = 11 },
				{ Name = "InvalidOAuthExpiration", Type = "ImageSharingResult", EnumValue = 12 },
				{ Name = "InvalidRefreshExpiration", Type = "ImageSharingResult", EnumValue = 13 },
				{ Name = "EncryptionSecretNotSet", Type = "ImageSharingResult", EnumValue = 14 },
			},
		},
		{
			Name = "PhotoSharingStatus",
			Type = "Enumeration",
			NumValues = 9,
			MinValue = 0,
			MaxValue = 8,
			Fields =
			{
				{ Name = "Disabled", Type = "PhotoSharingStatus", EnumValue = 0 },
				{ Name = "NotConfigured", Type = "PhotoSharingStatus", EnumValue = 1 },
				{ Name = "Configured", Type = "PhotoSharingStatus", EnumValue = 2 },
				{ Name = "Expired", Type = "PhotoSharingStatus", EnumValue = 3 },
				{ Name = "ParentalControl", Type = "PhotoSharingStatus", EnumValue = 4 },
				{ Name = "TrialOrVeteran", Type = "PhotoSharingStatus", EnumValue = 5 },
				{ Name = "AADCRestricted", Type = "PhotoSharingStatus", EnumValue = 6 },
				{ Name = "Error", Type = "PhotoSharingStatus", EnumValue = 7 },
				{ Name = "FailedToClear", Type = "PhotoSharingStatus", EnumValue = 8 },
			},
		},
		{
			Name = "PhotoSharingUploadStatus",
			Type = "Enumeration",
			NumValues = 30,
			MinValue = 0,
			MaxValue = 29,
			Fields =
			{
				{ Name = "Disabled", Type = "PhotoSharingUploadStatus", EnumValue = 0 },
				{ Name = "Failed", Type = "PhotoSharingUploadStatus", EnumValue = 1 },
				{ Name = "Success", Type = "PhotoSharingUploadStatus", EnumValue = 2 },
				{ Name = "Locked", Type = "PhotoSharingUploadStatus", EnumValue = 3 },
				{ Name = "ListPagesApiCallFailed", Type = "PhotoSharingUploadStatus", EnumValue = 4 },
				{ Name = "ListPagesBadRequest", Type = "PhotoSharingUploadStatus", EnumValue = 5 },
				{ Name = "ListPagesUnauthorized", Type = "PhotoSharingUploadStatus", EnumValue = 6 },
				{ Name = "ListPagesForbidden", Type = "PhotoSharingUploadStatus", EnumValue = 7 },
				{ Name = "ListPagesNotFound", Type = "PhotoSharingUploadStatus", EnumValue = 8 },
				{ Name = "ListPagesTooManyRequests", Type = "PhotoSharingUploadStatus", EnumValue = 9 },
				{ Name = "ListPagesGenericFailure", Type = "PhotoSharingUploadStatus", EnumValue = 10 },
				{ Name = "ListPagesEmptyBoardID", Type = "PhotoSharingUploadStatus", EnumValue = 11 },
				{ Name = "ListPagesInvalidBookmark", Type = "PhotoSharingUploadStatus", EnumValue = 12 },
				{ Name = "CreatePageApiCallFailed", Type = "PhotoSharingUploadStatus", EnumValue = 13 },
				{ Name = "CreatePageBadRequest", Type = "PhotoSharingUploadStatus", EnumValue = 14 },
				{ Name = "CreatePageUnauthorized", Type = "PhotoSharingUploadStatus", EnumValue = 15 },
				{ Name = "CreatePageForbidden", Type = "PhotoSharingUploadStatus", EnumValue = 16 },
				{ Name = "CreatePageNotFound", Type = "PhotoSharingUploadStatus", EnumValue = 17 },
				{ Name = "CreatePageTooManyRequests", Type = "PhotoSharingUploadStatus", EnumValue = 18 },
				{ Name = "CreatePageGenericFailure", Type = "PhotoSharingUploadStatus", EnumValue = 19 },
				{ Name = "CreatePageNoBoardIDFound", Type = "PhotoSharingUploadStatus", EnumValue = 20 },
				{ Name = "CreatePostApiCallFailed", Type = "PhotoSharingUploadStatus", EnumValue = 21 },
				{ Name = "CreatePostBadRequest", Type = "PhotoSharingUploadStatus", EnumValue = 22 },
				{ Name = "CreatePostUnauthorized", Type = "PhotoSharingUploadStatus", EnumValue = 23 },
				{ Name = "CreatePostForbidden", Type = "PhotoSharingUploadStatus", EnumValue = 24 },
				{ Name = "CreatePostNotFound", Type = "PhotoSharingUploadStatus", EnumValue = 25 },
				{ Name = "CreatePostTooManyRequests", Type = "PhotoSharingUploadStatus", EnumValue = 26 },
				{ Name = "CreatePostGenericFailure", Type = "PhotoSharingUploadStatus", EnumValue = 27 },
				{ Name = "CreatePostNoIDFound", Type = "PhotoSharingUploadStatus", EnumValue = 28 },
				{ Name = "CreatePostThrottled", Type = "PhotoSharingUploadStatus", EnumValue = 29 },
			},
		},
	},

	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(ImageSharingConstants);