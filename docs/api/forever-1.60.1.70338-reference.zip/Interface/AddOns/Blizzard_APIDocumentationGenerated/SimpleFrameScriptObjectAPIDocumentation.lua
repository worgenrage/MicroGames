local SimpleFrameScriptObjectAPI =
{
	Name = "SimpleFrameScriptObjectAPI",
	Type = "ScriptObject",
	Environment = "All",

	Functions =
	{
		{
			Name = "AddAccessRestrictions",
			Type = "Function",
			HasRestrictions = true,
			SecretArguments = "NotAllowed",
			Documentation = { "Adds access restrictions to a script object, preventing it from being used in API calls when enforced." },

			Arguments =
			{
				{ Name = "restrictions", Type = "ScriptObjectAccessRestriction", Nilable = false },
			},
		},
		{
			Name = "AddForbiddenAspects",
			Type = "Function",
			HasRestrictions = true,
			SecretArguments = "NotAllowed",
			Documentation = { "Adds forbidden aspects to a script object, restricting access to various functionalities such as script bindings." },

			Arguments =
			{
				{ Name = "aspects", Type = "ForbiddenAspect", Nilable = false },
			},
		},
		{
			Name = "AddSecretAspect",
			Type = "Function",
			HasRestrictions = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "aspect", Type = "SecretAspect", Nilable = false, NeverSecret = true },
			},
		},
		{
			Name = "CanBeAccessedInContext",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecurity },
			Documentation = { "Returns whether the current Lua execution context has permission to access this object." },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "canAccess", Type = "bool", Nilable = false, Documentation = { "False if access is denied, such as when execution is tainted and the object is forbidden or enforcing access restrictions." } },
			},
		},
		{
			Name = "GetAccessRestrictions",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecurity },
			Documentation = { "Returns the mask of all access restrictions applied to this object." },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "restrictions", Type = "ScriptObjectAccessRestriction", Nilable = false },
			},
		},
		{
			Name = "GetForbiddenAspects",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecurity },
			Documentation = { "Returns the mask of all forbidden aspects applied to this object." },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "aspects", Type = "ForbiddenAspect", Nilable = false },
			},
		},
		{
			Name = "GetInheritableForbiddenAspects",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecurity },
			SecretArguments = "NotAllowed",
			Documentation = { "Returns the mask of all forbidden aspects applied to this object that can propagate to others." },

			Arguments =
			{
				{ Name = "path", Type = "ScriptObjectPropagationPath", Nilable = false },
			},

			Returns =
			{
				{ Name = "aspects", Type = "ForbiddenAspect", Nilable = false },
			},
		},
		{
			Name = "GetName",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectName },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "name", Type = "cstring", Nilable = false },
			},
		},
		{
			Name = "GetObjectTable",
			Type = "Function",

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "objectTable", Type = "FrameScriptObject", Nilable = false },
			},
		},
		{
			Name = "GetObjectType",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectType },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "objectType", Type = "cstring", Nilable = false },
			},
		},
		{
			Name = "HasAccessConstraints",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecurity },
			Documentation = { "Returns whether this object has any access constraints that may limit access from some Lua execution contexts." },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "hasAccessConstraints", Type = "bool", Nilable = false, Documentation = { "True if this object is forbidden or subject to conditional access restrictions." } },
			},
		},
		{
			Name = "HasAnyAccessRestrictions",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecurity },
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Returns true if this object has any of the supplied access restrictions applied." },

			Arguments =
			{
				{ Name = "restrictions", Type = "ScriptObjectAccessRestriction", Nilable = true },
			},

			Returns =
			{
				{ Name = "hasAnyAccessRestriction", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "HasAnyForbiddenAspects",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecurity },
			SecretArguments = "AllowedWhenUntainted",
			Documentation = { "Returns true if this object has any of the supplied forbidden aspects added." },

			Arguments =
			{
				{ Name = "aspects", Type = "ForbiddenAspect", Nilable = true },
			},

			Returns =
			{
				{ Name = "hasAnyForbiddenAspect", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "HasAnySecretAspect",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecrets },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "hasSecretAspect", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "HasSecretAspect",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecrets },
			ConstSecretAccessor = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "aspect", Type = "SecretAspect", Nilable = false },
			},

			Returns =
			{
				{ Name = "hasSecretAspect", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "HasSecretValues",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecrets },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "hasSecretValues", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsForbidden",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecurity },
			Documentation = { "Returns whether this object has been explicitly marked as forbidden." },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "isForbidden", Type = "bool", Nilable = false, Documentation = { "True if this object has been explicitly marked as forbidden, regardless of the current Lua execution context." } },
			},
		},
		{
			Name = "IsObjectType",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectType },
			ConstSecretAccessor = true,
			SecretArguments = "AllowedWhenUntainted",

			Arguments =
			{
				{ Name = "objectType", Type = "cstring", Nilable = false },
			},

			Returns =
			{
				{ Name = "isType", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "IsPreventingSecretValues",
			Type = "Function",
			SecretReturnsForAspect = { Enum.SecretAspect.ObjectSecrets },

			Arguments =
			{
			},

			Returns =
			{
				{ Name = "isPreventingSecretValues", Type = "bool", Nilable = false },
			},
		},
		{
			Name = "SetForbidden",
			Type = "Function",
			HasRestrictions = true,

			Arguments =
			{
			},
		},
		{
			Name = "SetToDefaults",
			Type = "Function",
			IsProtectedFunction = true,
			ChecksForbiddenAspects = { { Argument = "self", Aspect = Enum.ForbiddenAspect.SetToDefaults }, { Argument = "self", Aspect = Enum.ForbiddenAspect.RemoveSecretAspects } },
			Documentation = { "Reset all script accessible values to their default values. If possible, clears secret states." },

			Arguments =
			{
			},
		},
	},

	Events =
	{
	},

	Tables =
	{
	},

	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(SimpleFrameScriptObjectAPI);