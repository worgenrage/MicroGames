local NameGenConstants =
{
	Tables =
	{
		{
			Name = "NamegenType",
			Type = "Enumeration",
			NumValues = 2,
			MinValue = 0,
			MaxValue = 1,
			Fields =
			{
				{ Name = "CharacterName", Type = "NamegenType", EnumValue = 0 },
				{ Name = "Surname", Type = "NamegenType", EnumValue = 1 },
			},
		},
	},

	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(NameGenConstants);