local DamageConstants =
{
	Tables =
	{
		{
			Name = "Causeofdeath",
			Type = "Enumeration",
			NumValues = 10,
			MinValue = 0,
			MaxValue = 9,
			Fields =
			{
				{ Name = "None", Type = "Causeofdeath", EnumValue = 0 },
				{ Name = "PlayerPvP", Type = "Causeofdeath", EnumValue = 1 },
				{ Name = "PlayerDuel", Type = "Causeofdeath", EnumValue = 2 },
				{ Name = "Creature", Type = "Causeofdeath", EnumValue = 3 },
				{ Name = "Falling", Type = "Causeofdeath", EnumValue = 4 },
				{ Name = "Drowning", Type = "Causeofdeath", EnumValue = 5 },
				{ Name = "Fatigue", Type = "Causeofdeath", EnumValue = 6 },
				{ Name = "Slime", Type = "Causeofdeath", EnumValue = 7 },
				{ Name = "Lava", Type = "Causeofdeath", EnumValue = 8 },
				{ Name = "Fire", Type = "Causeofdeath", EnumValue = 9 },
			},
		},
		{
			Name = "CauseofdeathFlags",
			Type = "Enumeration",
			NumValues = 4,
			MinValue = 0,
			MaxValue = 4,
			Fields =
			{
				{ Name = "NoneNeeded", Type = "CauseofdeathFlags", EnumValue = 0 },
				{ Name = "PlayerNameNeeded", Type = "CauseofdeathFlags", EnumValue = 1 },
				{ Name = "CreatureNameNeeded", Type = "CauseofdeathFlags", EnumValue = 2 },
				{ Name = "ZoneNameNeeded", Type = "CauseofdeathFlags", EnumValue = 4 },
			},
		},
		{
			Name = "Damageclass",
			Type = "Enumeration",
			NumValues = 46,
			MinValue = 0,
			MaxValue = 127,
			Fields =
			{
				{ Name = "Physical", Type = "Damageclass", EnumValue = 0 },
				{ Name = "Holy", Type = "Damageclass", EnumValue = 1 },
				{ Name = "Fire", Type = "Damageclass", EnumValue = 2 },
				{ Name = "Nature", Type = "Damageclass", EnumValue = 3 },
				{ Name = "Frost", Type = "Damageclass", EnumValue = 4 },
				{ Name = "Shadow", Type = "Damageclass", EnumValue = 5 },
				{ Name = "Arcane", Type = "Damageclass", EnumValue = 6 },
				{ Name = "FirstResist", Type = "Damageclass", EnumValue = 2 },
				{ Name = "LastResist", Type = "Damageclass", EnumValue = 6 },
				{ Name = "MaskNone", Type = "Damageclass", EnumValue = 0 },
				{ Name = "MaskPhysical", Type = "Damageclass", EnumValue = 1 },
				{ Name = "MaskHoly", Type = "Damageclass", EnumValue = 2 },
				{ Name = "MaskFire", Type = "Damageclass", EnumValue = 4 },
				{ Name = "MaskNature", Type = "Damageclass", EnumValue = 8 },
				{ Name = "MaskFrost", Type = "Damageclass", EnumValue = 16 },
				{ Name = "MaskShadow", Type = "Damageclass", EnumValue = 32 },
				{ Name = "MaskArcane", Type = "Damageclass", EnumValue = 64 },
				{ Name = "AllPhysical", Type = "Damageclass", EnumValue = 1 },
				{ Name = "AllMagical", Type = "Damageclass", EnumValue = 126 },
				{ Name = "All", Type = "Damageclass", EnumValue = 127 },
				{ Name = "MaskFlamestrike", Type = "Damageclass", EnumValue = 5 },
				{ Name = "MaskFroststrike", Type = "Damageclass", EnumValue = 17 },
				{ Name = "MaskSpellstrike", Type = "Damageclass", EnumValue = 65 },
				{ Name = "MaskShadowstrike", Type = "Damageclass", EnumValue = 33 },
				{ Name = "MaskStormstrike", Type = "Damageclass", EnumValue = 9 },
				{ Name = "MaskHolystrike", Type = "Damageclass", EnumValue = 3 },
				{ Name = "MaskFrostfire", Type = "Damageclass", EnumValue = 20 },
				{ Name = "MaskSpellfire", Type = "Damageclass", EnumValue = 68 },
				{ Name = "MaskFirestorm", Type = "Damageclass", EnumValue = 12 },
				{ Name = "MaskShadowflame", Type = "Damageclass", EnumValue = 36 },
				{ Name = "MaskHolyfire", Type = "Damageclass", EnumValue = 6 },
				{ Name = "MaskSpellfrost", Type = "Damageclass", EnumValue = 80 },
				{ Name = "MaskFroststorm", Type = "Damageclass", EnumValue = 24 },
				{ Name = "MaskShadowfrost", Type = "Damageclass", EnumValue = 48 },
				{ Name = "MaskHolyfrost", Type = "Damageclass", EnumValue = 18 },
				{ Name = "MaskSpellstorm", Type = "Damageclass", EnumValue = 72 },
				{ Name = "MaskSpellshadow", Type = "Damageclass", EnumValue = 96 },
				{ Name = "MaskDivine", Type = "Damageclass", EnumValue = 66 },
				{ Name = "MaskShadowstorm", Type = "Damageclass", EnumValue = 40 },
				{ Name = "MaskHolystorm", Type = "Damageclass", EnumValue = 10 },
				{ Name = "MaskTwilight", Type = "Damageclass", EnumValue = 34 },
				{ Name = "MaskElemental", Type = "Damageclass", EnumValue = 28 },
				{ Name = "MaskChromatic", Type = "Damageclass", EnumValue = 62 },
				{ Name = "MaskMagical", Type = "Damageclass", EnumValue = 126 },
				{ Name = "MaskChaos", Type = "Damageclass", EnumValue = 124 },
				{ Name = "MaskCosmic", Type = "Damageclass", EnumValue = 106 },
			},
		},
		{
			Name = "DamageclassType",
			Type = "Enumeration",
			NumValues = 2,
			MinValue = 0,
			MaxValue = 1,
			Fields =
			{
				{ Name = "Physical", Type = "DamageclassType", EnumValue = 0 },
				{ Name = "Magical", Type = "DamageclassType", EnumValue = 1 },
			},
		},
		{
			Name = "EnvironmentalDamageFlags",
			Type = "Enumeration",
			NumValues = 2,
			MinValue = 1,
			MaxValue = 2,
			Fields =
			{
				{ Name = "OneTime", Type = "EnvironmentalDamageFlags", EnumValue = 1 },
				{ Name = "DmgIsPct", Type = "EnvironmentalDamageFlags", EnumValue = 2 },
			},
		},
		{
			Name = "Environmentaldamagetype",
			Type = "Enumeration",
			NumValues = 6,
			MinValue = 0,
			MaxValue = 5,
			Fields =
			{
				{ Name = "Fatigue", Type = "Environmentaldamagetype", EnumValue = 0 },
				{ Name = "Drowning", Type = "Environmentaldamagetype", EnumValue = 1 },
				{ Name = "Falling", Type = "Environmentaldamagetype", EnumValue = 2 },
				{ Name = "Lava", Type = "Environmentaldamagetype", EnumValue = 3 },
				{ Name = "Slime", Type = "Environmentaldamagetype", EnumValue = 4 },
				{ Name = "Fire", Type = "Environmentaldamagetype", EnumValue = 5 },
			},
		},
	},

	Predicates =
	{
	},
};

APIDocumentation:AddDocumentationTable(DamageConstants);